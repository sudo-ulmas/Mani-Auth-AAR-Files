package uz.uzinfocom.myid

import android.content.Context
import androidx.annotation.Keep
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import uz.myid.android.sdk.capture.MyIdClient

@Keep
class MyIdPlugin : FlutterPlugin, MethodCallHandler, ActivityAware {

    private var myidSdk: MyIdSdk? = null
    private var activityListener: MyIdSdkActivityListener? = null
    private lateinit var methodChannel: MethodChannel
    private lateinit var applicationContext: Context
    private var currentBinding: ActivityPluginBinding? = null

    override fun onAttachedToEngine(flutterPluginBinding: FlutterPlugin.FlutterPluginBinding) {
        applicationContext = flutterPluginBinding.applicationContext
        methodChannel = MethodChannel(flutterPluginBinding.binaryMessenger, "myid_uz")
        methodChannel.setMethodCallHandler(this)
    }

    override fun onMethodCall(call: MethodCall, result: Result) {
        if (call.method == "startSdk") {
            ensureSdkInitialized()
            val config = call.arguments as HashMap<*, *>
            @Suppress("UNCHECKED_CAST")
            myidSdk?.start(config["config"] as? HashMap<String, Any?>, result)
        } else {
            result.notImplemented()
        }
    }

    private fun ensureSdkInitialized() {
        if (myidSdk != null) return

        val client = MyIdClient()
        val listener = MyIdSdkActivityListener(client)
        myidSdk = MyIdSdk(client, listener)
        activityListener = listener

        currentBinding?.let { binding ->
            myidSdk?.setActivity(binding.activity)
            binding.addActivityResultListener(listener)
        }
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        methodChannel.setMethodCallHandler(null)
    }

    override fun onAttachedToActivity(binding: ActivityPluginBinding) {
        currentBinding = binding
        myidSdk?.setActivity(binding.activity)
        activityListener?.let { binding.addActivityResultListener(it) }
    }

    override fun onDetachedFromActivity() {
        myidSdk?.setActivity(null)
        activityListener?.let { currentBinding?.removeActivityResultListener(it) }
        currentBinding = null
    }

    override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding) {
        onAttachedToActivity(binding)
    }

    override fun onDetachedFromActivityForConfigChanges() {
        onDetachedFromActivity()
    }
}
